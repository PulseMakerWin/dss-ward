module.exports = {
  chainLogAddress: '0xdA0Ab1e0017DEbCd72Be8599041a2aa3bA7e740F',
  mcdDeployment: 8928152,
  batchSize: 10000,
};
